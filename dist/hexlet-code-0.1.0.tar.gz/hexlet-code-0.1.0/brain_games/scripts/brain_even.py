#!/usr/bin/env python
import prompt
from random import randint

def greet():
    print('Welcome to the Brain Games!')


greet()

name = prompt.string('May I have your name? ')


def welcome_user():
    print('Hello, ' + name + '!')

welcome_user()

print('Answer "yes" if the number is even, otherwise answer "no".')

def game_description():
  i = 1

  while i <= 3:
    random_number = randint(1, 100)
    print('Question: ' + str(random_number))
    user_answer = input("Your answer: ")
    
    if random_number % 2 == 0 and user_answer == 'yes' or random_number % 2 != 0 and user_answer == 'no':
        print('Correct!') 

    elif random_number % 2 != 0 and user_answer == 'yes': 
        print("'yes' is wrong answer. Correct answer was 'no'.\nLet's try again, " + name + "!")
        exit()
    elif random_number % 2 == 0 and user_answer == 'no':
        print("'no' is wrong answer. Correct answer was 'yes'.\nLet's try again, " + name + "!")
        exit()
    else:
        print("This is an incorrect answer.\nLet's try again, " + name + "!")
        exit()
    i += 1
  print('Congratulations,' + name + '!')
game_description()

def main():
    game_description()


if __name__ == '__main__':
    main()